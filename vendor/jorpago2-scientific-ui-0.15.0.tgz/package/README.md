# @jorpago2/scientific-ui

Small, Carbon-compatible utilities for scientific results. Applications own their shell, navigation, forms and actions with Carbon React directly.

## Main API

The default entry point contains only domain-oriented building blocks:

- scientific outcome, evidence, validation, provenance and model-scope layouts;
- Plotly theme, layout, configuration and toolbar helpers;
- scientific number parsing and formatting;
- autosave serialization and recovery logic;
- result freshness and reveal transitions;
- shared scientific state and descriptor types.

```tsx
import {
  ScientificOutcomeSummary,
  ScientificValidationSummary,
  createScientificPlotlyLayout,
  useScientificAutosave,
} from "@jorpago2/scientific-ui";
import "@jorpago2/scientific-ui/styles.css";
```

Use Carbon React directly for headers, side navigation, task panels, buttons, fields, themes and notifications. The package does not own application chrome or numerical state.

Version 0.15 removes the former shell wrappers from the published API. Existing applications may remain pinned to 0.14 while they migrate to Carbon primitives.

## Plot contract

`SCIENTIFIC_PLOT_LINE_WIDTHS` defines trace hierarchy. `ScientificPlotFrame`, `createScientificPlotlyLayout`, `createScientificPlotlyConfig` and `prepareScientificPlotlyToolbar` keep typography, tokens, export, reset, fullscreen and keyboard behavior consistent. Series colours and physical semantics remain application-owned.

## CSS ownership

Carbon owns component appearance and interaction. Shared CSS supplies scientific result layouts and tokens. Consumers must not target Carbon internal classes.

## Commands

- `pnpm test`
- `pnpm typecheck`
- `pnpm build`
- `pnpm test:ui`
- `pnpm check:conformance`

Consumers provide React 19.2, React DOM 19.2 and Carbon React 1.113.
